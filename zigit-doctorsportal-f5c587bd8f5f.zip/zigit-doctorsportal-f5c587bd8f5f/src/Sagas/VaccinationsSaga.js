import { takeEvery, put } from 'redux-saga/effects';
import { setVaccinations, FETCH_VACCINATIONS, setVaccinationsStatus } from '../Actions/Vaccinations';
import { Api } from '../Services';
import { parseQuery } from '../Utils/UrlParams';
import { ACTION_STATUS } from '../Consts';

// /fetch member vaccinations and set to store
export function* vaccinationsSaga() {
  const { memberId, memberIdcode } = parseQuery();
  yield put(setVaccinationsStatus(ACTION_STATUS.pending));
  try {
    const vaccinations = yield Api.VaccinationsService.fetchVaccinations(memberId, memberIdcode);
    yield put(setVaccinations(vaccinations));
  } catch (e) {
    yield put(setVaccinationsStatus(ACTION_STATUS.error, e.message ? e.message : e));
  }
}

export function* vaccinationsActionWatcher() {
  yield takeEvery(FETCH_VACCINATIONS, vaccinationsSaga);
}
