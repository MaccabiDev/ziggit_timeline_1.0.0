import { takeEvery, put } from 'redux-saga/effects';
import { setAllergies, FETCH_ALLERGIES, setAllergiesStatus } from '../Actions/Allergies';
import { Api } from '../Services';
import { parseQuery } from '../Utils/UrlParams';
import { ACTION_STATUS } from '../Consts';

// fetch member allergies and set to store
export function* allergiesSaga() {
  const { memberId, memberIdcode } = parseQuery();
  yield put(setAllergiesStatus(ACTION_STATUS.pending));
  try {
    const respone = yield Api.allergiesService.fetchAllergies(memberId, memberIdcode);
    yield put(setAllergies(respone.Results));
  } catch (e) {
    yield put(setAllergiesStatus(ACTION_STATUS.error, e.message ? e.message : e));
  }
}

export function* allergiesActionWatcher() {
  yield takeEvery(FETCH_ALLERGIES, allergiesSaga);
}
