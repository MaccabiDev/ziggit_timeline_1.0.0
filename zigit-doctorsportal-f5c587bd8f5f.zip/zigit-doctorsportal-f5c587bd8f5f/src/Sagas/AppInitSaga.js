import { takeLatest, put } from 'redux-saga/effects';
import { fetchMemberInformation, fetchRegistries } from '../Actions/PatientDetails'
import { fetchAllergies } from '../Actions/Allergies'
import { fetchVaccinations } from '../Actions/Vaccinations'
import { APP_INIT } from '../Actions/AppInit';

// app initialization
export function* appInitSaga() {
  yield put(fetchMemberInformation());
  yield put(fetchRegistries());
  yield put(fetchAllergies());
  yield put(fetchVaccinations());
}

export function* appInitWatcher() {
  yield takeLatest(APP_INIT, appInitSaga);
}
