import { takeEvery, put } from 'redux-saga/effects';
import { FETCH_MEMBER_INFORMATION, setMemberInformation, setMemberInformationStatus } from '../Actions/PatientDetails';
import { Api } from '../Services';
import { parseQuery } from '../Utils/UrlParams';
import { ACTION_STATUS } from '../Consts';

// fetch member inforamtion  set to store
export function* memberInformationSaga() {
  const { memberId, memberIdcode } = parseQuery();
  yield put(setMemberInformationStatus(ACTION_STATUS.pending));
  try {
    const memberInformation = yield Api.memberInformationService.fetchMemberInformation(memberId, memberIdcode);
    yield put(setMemberInformation(memberInformation));
  } catch (e) {
    yield put(setMemberInformationStatus(ACTION_STATUS.error, e.message ? e.message : e));
  }
}

export function* memberInformationActionWatcher() {
  yield takeEvery(FETCH_MEMBER_INFORMATION, memberInformationSaga);
}
