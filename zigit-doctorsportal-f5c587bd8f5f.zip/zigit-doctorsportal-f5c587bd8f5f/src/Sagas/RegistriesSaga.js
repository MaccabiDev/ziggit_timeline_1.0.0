import { takeEvery, put } from 'redux-saga/effects';
import { FETCH_REGISTRIES, setRegistries, setRegestriesStatus } from '../Actions/PatientDetails';
import { Api } from '../Services';
import { VALID_REGESTRIES_CODES, ACTION_STATUS } from '../Consts';
import { parseQuery } from '../Utils/UrlParams';

// fetch regestries and set to store
export function* registrysSaga() {
  const { memberId, memberIdcode } = parseQuery();
  yield put(setRegestriesStatus(ACTION_STATUS.pending));
  try {
    const registries = yield Api.registriesService.fetchRegistries(memberId, memberIdcode);
    registries.filter((r) => VALID_REGESTRIES_CODES.find((v) => v === r.registry_code))
    yield put(setRegistries(registries));
  } catch (e) {
    yield put(setRegestriesStatus(ACTION_STATUS.error, e.message ? e.message : e));
  }
}

export function* registriesActionWatcher() {
  yield takeEvery(FETCH_REGISTRIES, registrysSaga);
}
