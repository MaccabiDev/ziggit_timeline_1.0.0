import { all } from 'redux-saga/effects'
import { memberInformationActionWatcher } from './MemberInformationSaga'
import { registriesActionWatcher } from './RegistriesSaga'
import { allergiesActionWatcher } from './AllergiesSaga'
import { vaccinationsActionWatcher } from './VaccinationsSaga'
import { appInitWatcher } from './AppInitSaga'

export default function * rootSaga() {
  yield all([
    memberInformationActionWatcher(),
    registriesActionWatcher(),
    allergiesActionWatcher(),
    vaccinationsActionWatcher(),
    appInitWatcher()
  ])
}
