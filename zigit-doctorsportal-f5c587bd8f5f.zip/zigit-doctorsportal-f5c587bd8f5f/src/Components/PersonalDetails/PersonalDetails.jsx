/* eslint-disable camelcase */
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Flex, Text } from '../../UI';
import './PersonalDetails.scss'
import { Link } from '../../UI/Link/Link';
import info from '../../Assets/Images/info.svg';
import contact from '../../Assets/Images/contact.svg';
import { ageByGender } from '../../Utils/TextUtils';
import { Avatar } from '../Avatar/Avatar';
import { STATUS_MEMBERSHIPS } from '../../Consts';

export const PersonalDetails = memo((props) => {
  const { memberInformation } = props;
  const { age, f_name_hebrew, l_name_hebrew, sex, ascribed, status_membership, phones, member_id } = memberInformation;
  const { first_name, last_name, s_p_clinic_srteet, s_p_clinic_house_num, s_p_clinic_city } = ascribed;
  return (
    <Flex className={'personal-details'} row>
      <Avatar age={age} gender={sex}/>
      <Flex className={'personal-details__text-container'}>
        <Flex align={'center'} row>
          <Text className={'personal-details__name'} weight={'bold'} color={'primary'}>{`${f_name_hebrew} ${l_name_hebrew}`}</Text>
          <Text color={'standard-dark'}>{ageByGender(age, sex)}</Text>
          <Text color={'standard-dark'}>{`ת.ז ${member_id}`}</Text>
          <Text weight={'bold'} color={'primary'}>{STATUS_MEMBERSHIPS[status_membership]}</Text>
        </Flex>
        <Text>ילדים 3</Text>
        <Flex wrap row>
          <Text>{`רופא משוייך: ד"ר ${first_name} ${last_name}, ${s_p_clinic_srteet} ${s_p_clinic_house_num} ${s_p_clinic_city}  `}</Text>
          <Link>שינוי רופא קבוע</Link>
        </Flex>
        <Flex wrap className={'personal-details__contact-container'} row>
          <Flex row>
            <Text>{`טלפון: ${phones[0].phone_no}`}</Text>
            <span className={'personal-details__seperator'}>|</span>
            <Text className={'personal-details__addional-phone'}>{`טלפון נוסף: ${phones[1].phone_no}`}</Text>
          </Flex>
          <Flex row>
            <span className={'personal-details__seperator'}>|</span>
            <img className={'personal-details__info-ic'} src={info}/>
            <Text>עדכון פרטים</Text>
          </Flex>
          <Flex row>
            <span className={'personal-details__seperator'}>|</span>
            <img className={'personal-details__info-ic'} src={contact}/>
            <Text>חיוג מחסוי</Text>
          </Flex>
        </Flex>

      </Flex>

    </Flex>
  )
})

PersonalDetails.propTypes = {
  memberInformation: PropTypes.object,
  memberId: PropTypes.string

}
