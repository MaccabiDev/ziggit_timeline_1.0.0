import React, { memo } from 'react';
import PropTypes from 'prop-types';
import avatarM0 from '../../Assets/Images/avatarM0.svg'
import avatarM3 from '../../Assets/Images/avatarM3.svg'
import avatarM7 from '../../Assets/Images/avatarM7.svg'
import avatarM12 from '../../Assets/Images/avatarM12.svg'
import avatarM19 from '../../Assets/Images/avatarM19.svg'
import avatarM30 from '../../Assets/Images/avatarM30.svg'
import avatarM45 from '../../Assets/Images/avatarM45.svg'
import avatarM65 from '../../Assets/Images/avaterM65.svg'

import avatarW0 from '../../Assets/Images/avatarW0.svg';
import avatarW3 from '../../Assets/Images/avatarW3.svg'
import avatarW7 from '../../Assets/Images/avatarW7.svg'
import avatarW12 from '../../Assets/Images/avatarW12.svg'
import avatarW19 from '../../Assets/Images/avatarW19.svg'
import avatarW30 from '../../Assets/Images/avatarW30.svg'
import avatarW45 from '../../Assets/Images/avatarW45.svg'
import avatarW65 from '../../Assets/Images/avatarW65.svg'
import { AVATAR_AGES_RANGE, GENDER } from '../../Consts';

export const Avatar = memo(({ age, gender }) => {
  let avatar = '';

  const isMan = gender === GENDER.male;
  if (age > AVATAR_AGES_RANGE[0].min && age <= AVATAR_AGES_RANGE[0].max) {
    avatar = isMan ? avatarM0 : avatarW0;
  } else if (age > AVATAR_AGES_RANGE[1].min && age <= AVATAR_AGES_RANGE[1].max) {
    avatar = isMan ? avatarM3 : avatarW3;
  } else if (age > AVATAR_AGES_RANGE[2].min && age <= AVATAR_AGES_RANGE[2].max) {
    avatar = isMan ? avatarM7 : avatarW7;
  } else if (age > AVATAR_AGES_RANGE[3].min && age <= AVATAR_AGES_RANGE[3].max) {
    avatar = isMan ? avatarM12 : avatarW12;
  } else if (age > AVATAR_AGES_RANGE[4].min && age <= AVATAR_AGES_RANGE[4].max) {
    avatar = isMan ? avatarM19 : avatarW19;
  } else if (age > AVATAR_AGES_RANGE[5].min && age <= AVATAR_AGES_RANGE[5].max) {
    avatar = isMan ? avatarM30 : avatarW30;
  } else if (age > AVATAR_AGES_RANGE[6].min && age <= AVATAR_AGES_RANGE[6].max) {
    avatar = isMan ? avatarM45 : avatarW45;
  } else {
    avatar = isMan ? avatarM65 : avatarW65;
  }

  return (
    <img src={avatar}/>
  )
})

Avatar.propTypes = {
  age: PropTypes.number,
  gender: PropTypes.oneOf([GENDER.male, GENDER.female])

}
