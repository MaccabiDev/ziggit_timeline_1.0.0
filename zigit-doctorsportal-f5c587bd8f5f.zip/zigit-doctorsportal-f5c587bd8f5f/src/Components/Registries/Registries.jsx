import React, { memo } from 'react';
import './Registries.scss'
import { TagsList } from '../../UI/Tags/TagsList/TagsList';
import PropTypes from 'prop-types';

export const Registries = memo(({ registries }) => {
  return (
    <TagsList classes={{ item: 'registers-details__item' }} maxPerRow={3} tags ={registries.map((r) => r.registry_name)}/>
  )
})

Registries.propTypes = {
  registries: PropTypes.array
}
