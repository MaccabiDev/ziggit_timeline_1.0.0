import React, { memo } from 'react';
import { Flex } from '../../UI'
import './PortalGrid.scss';
import { Allergies, Vaccinations, RisksFactors, Diagnoses, Timeline, Medicines } from '../../Containers';
export const PortalGrid = memo((props) => {
  return (
    <Flex className={'portal-grid'} fullWidth row>
      <Flex className={'portal-grid__right'}>
        <Flex fullWidth row>
          <Medicines/>
          <Flex className={'portal-grid__right-inner'}>
            <RisksFactors/>
            <Allergies/>
            <Vaccinations/>
          </Flex>
        </Flex>
        <Timeline/>
      </Flex>
      <Flex className={'portal-grid__left '}>
        <Diagnoses/>
      </Flex>
    </Flex>
  )
})
