import React, { memo } from 'react';
import './Remarks.scss'
import { TagsList } from '../../UI/Tags/TagsList/TagsList';
import PropTypes from 'prop-types';
import { REMARKS_SHORT_TEXTS } from '../../Consts';

export const Remarks = memo(({ remarks }) => {
  const remarksShortTextsUnique = remarks.map((r) => {
    const shortDesc = REMARKS_SHORT_TEXTS[r.remark_code] // short desciption if exists, otherwise full description
    return shortDesc || r.remark_body
  })
    .filter((value, index, self) => self.indexOf(value) === index) // filter values that already exists
  return (
    <TagsList classes={{ item: 'remarks-details__item' }} maxPerRow={3} tags ={remarksShortTextsUnique}/>
  )
})
Remarks.propTypes = {
  remarks: PropTypes.array
}
