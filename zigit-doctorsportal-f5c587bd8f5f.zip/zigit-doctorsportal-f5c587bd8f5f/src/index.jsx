import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import './index.scss';
import { DoctorsPortalApp } from './Containers/DoctorsPortalApp/DoctorsPortalApp.jsx'

import store from './Store/Store';

ReactDOM.render(
  <Provider store={store}>
    <DoctorsPortalApp />
  </Provider>, document.getElementById('root')
);
