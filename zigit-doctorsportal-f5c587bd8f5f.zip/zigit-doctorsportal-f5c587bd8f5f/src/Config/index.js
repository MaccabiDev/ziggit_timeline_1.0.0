import { devConfig } from './Config.dev';
import { stagingConfig } from './Config.staging';
import { productionConfig } from './Config.production';

// use configuration file based on build time 'REACT_APP_ENV' enviorment varible
let envConfig;
if (process.env.REACT_APP_ENV === 'production') {
  envConfig = productionConfig;
} else if (process.env.REACT_APP_ENV === 'staging') {
  envConfig = stagingConfig;
} else {
  envConfig = devConfig;
}
export const config = envConfig;
