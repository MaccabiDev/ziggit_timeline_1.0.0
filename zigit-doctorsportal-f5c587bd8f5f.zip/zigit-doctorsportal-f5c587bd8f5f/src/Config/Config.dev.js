
export const devConfig = {
  baseUrl: 'https://dev',
  printLogs: true
};
