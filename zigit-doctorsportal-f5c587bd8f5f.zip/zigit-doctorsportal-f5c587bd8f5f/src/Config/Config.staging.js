
export const stagingConfig = {
  baseUrl: 'https://staging',
  printLogs: true
};
