
export const productionConfig = {
  baseUrl: 'https://prod',
  printLogs: false
};
