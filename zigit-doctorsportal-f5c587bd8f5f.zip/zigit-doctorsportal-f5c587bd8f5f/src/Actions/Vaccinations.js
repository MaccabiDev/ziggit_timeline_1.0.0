
// set vaccinations to store
export const SET_VACCINATIONS = 'SET_VACCINATIONS';
export const setVaccinations = (vaccinations) => ({
  type: SET_VACCINATIONS,
  vaccinations
});

// watched by vaccinationsActionWatcher and will trigger http request to Vaccinations service
export const FETCH_VACCINATIONS = 'FETCH_VACCINATIONS';
export const fetchVaccinations = () => ({
  type: FETCH_VACCINATIONS
})

// set the status of fetchVaccinations request
export const SET_VACCINATIONS_STATUS = 'SET_VACCINATIONS_STATUS';
export const setVaccinationsStatus = (status, error) => ({
  type: SET_VACCINATIONS_STATUS,
  status,
  error
})
