/**
 * watched by appInitWatcher and will trigger:
 * fetchMemberInformation
 * fetchRegistries
 * fetchAllergies
 * fetchVaccinations
 */
export const APP_INIT = 'APP_INIT';
export const appInit = () => ({
  type: APP_INIT
})
