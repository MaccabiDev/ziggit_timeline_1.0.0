
// set memberInformation to store
export const SET_MEMBER_INFORMATION = 'SET_MEMBER_INFORMATION';
export const setMemberInformation = (memberInformation) => ({
  type: SET_MEMBER_INFORMATION,
  memberInformation
});

// watched by memberInformationActionWatcher and will trigger http request to memberInformationActionWatcher service
export const FETCH_MEMBER_INFORMATION = 'FETCH_MEMBER_INFORMATION';
export const fetchMemberInformation = () => ({
  type: FETCH_MEMBER_INFORMATION
});

// watched by memberInformationActionWatcher and will trigger http request to memberInformationActionWatcher service
export const FETCH_REGISTRIES = 'FETCH_REGISTRIES';
export const fetchRegistries = () => ({
  type: FETCH_REGISTRIES
});

// set regestries to store
export const SET_REGISTRIES = 'SET_REGISTRIES';
export const setRegistries = (registries) => ({
  type: SET_REGISTRIES,
  registries
});

// set the status of fetchRegistries request
export const SET_REGISTRIES_STATUS = 'SET_REGISTRIES_STATUS';
export const setRegestriesStatus = (regestiresStatus, regestiresError = null) => ({
  type: SET_REGISTRIES_STATUS,
  regestiresStatus,
  regestiresError
})

// set the status of fetchMemberInformation request
export const SET_MEMBER_INFORMATION_STATUS = 'SET_MEMBER_INFORMATION_STATUS';
export const setMemberInformationStatus = (memberInformationStatus, memberInformationError = null) => ({
  type: SET_MEMBER_INFORMATION_STATUS,
  memberInformationStatus,
  memberInformationError
})
