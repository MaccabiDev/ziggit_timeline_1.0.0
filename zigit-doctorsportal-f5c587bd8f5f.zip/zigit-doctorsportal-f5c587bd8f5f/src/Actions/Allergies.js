
// set list of allergies to store
export const SET_ALLERGIES = 'SET_ALLERGIES';
export const setAllergies = (allergies) => ({
  type: SET_ALLERGIES,
  allergies
});

// watched by allergiesActionWatcher and will trigger http request to allergies service
export const FETCH_ALLERGIES = 'FETCH_ALLERGIES';
export const fetchAllergies = () => ({
  type: FETCH_ALLERGIES
})

// set the status of fetchAllergies request
export const SET_ALLERGIES_STATUS = 'SET_ALLERGIES_STATUS';
export const setAllergiesStatus = (status, error) => ({
  type: SET_ALLERGIES_STATUS,
  status,
  error
})
