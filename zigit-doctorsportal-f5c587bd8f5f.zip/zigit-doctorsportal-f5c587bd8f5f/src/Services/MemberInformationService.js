
import axios from 'axios';
import { sleep } from './AllergiesService';

export class MemberInformationService {
  constructor(baseURL) {
    this.client = axios.create({ baseURL })
  }

  async fetchMemberInformation(memberIdCode, memberId) {
    await sleep(800);
    return {
      member_id: '372397239',
      f_name_hebrew: 'ישראלה',
      l_name_hebrew: 'כהן',
      sex: 'נ',
      age: 22,
      ascribed: {
        first_name: 'ישראל',
        last_name: 'ישראלי',
        s_p_clinic_srteet: 'התאחדות',
        s_p_clinic_house_num: '10',
        s_p_clinic_city: 'חולון'
      },
      phones_update_date: '2018-07-11T00:00:00',
      email: '',
      unifier_phone_prefix: '52',
      unifier_phone: 6150628,
      unifier_email: '',
      language_code: 7,
      language_description: 'ספרדית',
      phones: [
        {
          phone_type: 'ב',
          phone_prefix: '3',
          phone_no: 5149898,
          fax_special_prefix: '0'
        },
        {
          phone_type: 'נ',
          phone_prefix: '52',
          phone_no: 6150628,
          fax_special_prefix: '0'
        },
        {
          phone_type: 'פ',
          phone_prefix: '4',
          phone_no: 9108818,
          fax_special_prefix: '0'
        }
      ],
      macabiton_type: 'ר',
      branch: 'נהריה',
      x_coordinate: '34.792841',
      y_coordinate: '32.057613',
      statistical_area: 50000926,
      addresses: [
        {
          address_status: 'מ',
          address_type: 'ד',
          city_code_maccabi: 51318,
          postal_code: '5000',
          city_name: 'תל אביב - יפו',
          street_code: '2bbf',
          street_name: 'קיש',
          house_num: '45',
          entrance: 'א',
          apartment_num: '3',
          po_box: 0,
          zip_code: 6761020,
          address_for_mail: '20180715'
        },
        {
          address_status: 'מ',
          address_type: 'מ',
          city_code_maccabi: 51318,
          postal_code: '5000',
          city_name: 'תל אביב - יפו',
          street_code: '2bbf',
          street_name: 'קיש',
          house_num: '45',
          entrance: 'א',
          apartment_num: '3',
          po_box: 0,
          zip_code: 6761020,
          address_for_mail: '20180719'
        },
        {
          address_status: 'פ',
          address_type: 'ד',
          city_code_maccabi: 31013,
          postal_code: '4000',
          city_name: 'חיפה',
          street_code: '3434',
          street_name: 'שד אבא חושי',
          house_num: '20',
          entrance: '',
          apartment_num: '',
          po_box: 0,
          zip_code: 3478623,
          address_for_mail: '20180711'
        }
      ],
      status_membership: 1,
      status_reason: 1,
      membership_situation_start_date: '1993-04-01T00:00:00',
      membership_expected_end_date: '2039-12-31T00:00:00',
      membership_start_date: '1993-04-01T00:00:00',
      membership_paid_until_date: '1806',
      insurances_groups: [
        {
          ins_type_code: '02',
          ins_status: 1,
          ins_reason: 1,
          ins_situation_start_date: '1993-04-01T00:00:00',
          ins_expected_end_date: '2039-12-31T00:00:00',
          ins_start_date: '1993-04-01T00:00:00',
          ins_payed_until_date: '1806',
          ins_seniority_date: '1993-04-01T00:00:00',
          previous_shaban_seniority_date: null,
          previous_shaban_type: '',
          ltc_code: 0,
          entrance_age: 24.8,
          maccabi_ltc_code_layer: ''
        },
        {
          ins_type_code: '04',
          ins_status: 1,
          ins_reason: 1,
          ins_situation_start_date: '1995-01-01T00:00:00',
          ins_expected_end_date: '2039-12-31T00:00:00',
          ins_start_date: '1995-01-01T00:00:00',
          ins_payed_until_date: '1806',
          ins_seniority_date: '1993-04-01T00:00:00',
          previous_shaban_seniority_date: null,
          previous_shaban_type: '',
          ltc_code: 0,
          entrance_age: 24.8,
          maccabi_ltc_code_layer: ''
        },
        {
          ins_type_code: '05',
          ins_status: 2,
          ins_reason: 23,
          ins_situation_start_date: '2016-07-01T00:00:00',
          ins_expected_end_date: '2039-12-31T00:00:00',
          ins_start_date: '1993-04-01T00:00:00',
          ins_payed_until_date: '1606',
          ins_seniority_date: '1993-04-01T00:00:00',
          previous_shaban_seniority_date: null,
          previous_shaban_type: '',
          ltc_code: 0,
          entrance_age: 24.81,
          maccabi_ltc_code_layer: ''
        },
        {
          ins_type_code: '08',
          ins_status: 1,
          ins_reason: 1,
          ins_situation_start_date: '2016-07-01T00:00:00',
          ins_expected_end_date: '2039-12-31T00:00:00',
          ins_start_date: '2016-07-01T00:00:00',
          ins_payed_until_date: '1806',
          ins_seniority_date: '1993-04-01T00:00:00',
          previous_shaban_seniority_date: null,
          previous_shaban_type: '',
          ltc_code: 60,
          entrance_age: 24.8,
          maccabi_ltc_code_layer: '1'
        }
      ],
      remarks: [
        {
          remark_number: 5,
          remark_code: 6052,
          remark_body: 'נפגע תאונת עבודה - הוכר ע"י ביטוח לאומי',
          remark_start_date: '2006-12-01T00:00:00',
          remark_end_date: null
        },
        {
          remark_number: 6,
          remark_code: 1420,
          remark_body: 'חולה כרוני(עפ"י מ.הבריאות)-תקרה לתרופות',
          remark_start_date: '2009-01-01T00:00:00',
          remark_end_date: null
        },
        {
          remark_number: 7,
          remark_code: 7101,
          remark_body: 'אותר דרך רשם.אין חובת רכישה בה.ק.',
          remark_start_date: '2009-01-01T00:00:00',
          remark_end_date: null
        },
        {
          remark_number: 9,
          remark_code: 6050,
          remark_body: 'תאונת עבודה-הוקלד ב.ל. 283/250',
          remark_start_date: '2009-09-10T00:00:00',
          remark_end_date: null
        },
        {
          remark_number: 10,
          remark_code: 1441,
          remark_body: 'זכאי לתרופת מ.זהב שלא מאריכה/מצילה חיים',
          remark_start_date: '2010-01-01T00:00:00',
          remark_end_date: null
        }
      ]

    }
  }
}
