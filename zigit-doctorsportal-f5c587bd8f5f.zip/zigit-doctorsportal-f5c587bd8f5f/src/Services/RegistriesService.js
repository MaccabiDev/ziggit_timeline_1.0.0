
import axios from 'axios';
import { sleep } from './AllergiesService';

export class RegistriesService {
  constructor(baseURL) {
    this.client = axios.create({ baseURL })
  }

  async fetchRegistries(memberIdCode, memberId) {
    await sleep(500);
    return [
      {
        registry_code: 1,
        registry_name: 'לב וכלי דם',
        disease_main_grp_code: 1,
        disease_main_grp: 'מחלות עקריות'
      },
      {
        registry_code: 4,
        registry_name: 'יתר לחץ דם',
        disease_main_grp_code: 1,
        disease_main_grp: 'רשם יתר לחץ דם'
      },
      {
        registry_code: 12,
        registry_name: 'טרום סוכרת',
        disease_main_grp_code: 1,
        disease_main_grp: 'טרום סוכרת'
      },
      {
        registry_code: 13,
        registry_name: 'תחלואת עצם',
        disease_main_grp_code: 1,
        disease_main_grp: 'אוסטיאופורוזיס'
      }]
  }
}
