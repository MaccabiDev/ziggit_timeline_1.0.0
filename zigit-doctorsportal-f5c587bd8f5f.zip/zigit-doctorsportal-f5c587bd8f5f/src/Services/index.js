
import { config } from '../Config';
import { MemberInformationService } from './MemberInformationService';
import { RegistriesService } from './RegistriesService';
import { AllergiesService } from './AllergiesService';
import { VaccinationsService } from './VaccinationsService';

/**
 * Api object contains instances of all serivces
 */
export const Api = {
  memberInformationService: new MemberInformationService(config.baseUrl),
  registriesService: new RegistriesService(config.baseUrl),
  allergiesService: new AllergiesService(config.baseUrl),
  VaccinationsService: new VaccinationsService(config.baseUrl)
};
