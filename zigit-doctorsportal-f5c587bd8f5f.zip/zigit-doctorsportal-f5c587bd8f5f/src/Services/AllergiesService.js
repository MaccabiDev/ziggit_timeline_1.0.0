
import axios from 'axios';

export class AllergiesService {
  constructor(baseURL) {
    this.client = axios.create({ baseURL })
  }

  async fetchAllergies(memberIdCode, memberId) {
    await sleep(2000);
    return {
      error_code: '',
      error_massage: '',
      Results: [
        {
          drug_weakness: 'שלשולים ',
          drug_name: 'DEXAMOL',
          drug_date_registration: '2018-07-11T00:00:00',
          drug_notes: '',
          Id_drug_additional: '7913',
          drug_additional: 'תרופה'
        },
        {
          drug_weakness: 'כאבי בטן ',
          drug_name: 'חלב',
          drug_date_registration: '2018-07-11T00:00:00',
          drug_notes: '',
          Id_drug_additional: '',
          drug_additional: 'אחר'

        }

      ]
    }
  }
}

export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
