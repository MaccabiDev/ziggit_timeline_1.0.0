
import axios from 'axios';
import { sleep } from './AllergiesService';

export class VaccinationsService {
  constructor(baseURL) {
    this.client = axios.create({ baseURL })
  }

  async fetchVaccinations(memberIdCode, memberId) {
    await sleep(1500);
    return [
      {
        VaccineGroupName: 'DTP/DTAP',
        LastDate: '2039-12-31T00:00:00',
        VaccinationsAmount: 1
      },
      {
        VaccineGroupName: 'H1N1',
        LastDate: '2039-12-31T00:00:00',
        VaccinationsAmount: 2
      },
      {
        VaccineGroupName: 'פוליו IPV',
        LastDate: '2039-12-31T00:00:00',
        VaccinationsAmount: 1
      }
    ]
  }
}
