import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';
import logger from 'redux-logger';
import rootReducer from '../Reducers';
import rootSaga from '../Sagas';
import { config } from '../Config';

const sagaMiddleware = createSagaMiddleware();
let middlewares = [sagaMiddleware];
if (config.printLogs) { // add logger middlewares only if printLogs set to true
  middlewares = [...middlewares, logger];
}
export default createStore(rootReducer, applyMiddleware(...middlewares));
sagaMiddleware.run(rootSaga);
