import React from 'react';
import { Box } from '../../UI';
import './Diagnoses.scss';

export const Diagnoses = (props) => {
  return (
    <div className={'diagnoses'}>
      <Box classes={{ box: 'diagnoses__box' }} title={'אבחנות'}>

      </Box>
    </div>

  )
}
