import React from 'react';
import { Box } from '../../UI';
import './RisksFactors.scss';

export const RisksFactors = (props) => {
  return (
    <div className={'risks-factors'}>
      <Box classes={{ box: 'risks-factors__box' }} title={'גורמי סיכון'}>

      </Box>
    </div>

  )
}
