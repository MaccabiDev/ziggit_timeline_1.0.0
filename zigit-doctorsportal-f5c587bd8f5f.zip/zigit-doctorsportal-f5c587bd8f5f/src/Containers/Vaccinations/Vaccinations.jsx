import React from 'react';
import { Box, Text } from '../../UI';
import './Vaccinations.scss';
import { DynamicTable } from '../../UI/DynamicTable/DynamicTable';
import { useSelector } from 'react-redux';
import { formatDate } from '../../Utils/DatesUtils';
export const Vaccinations = (props) => {
  const vaccinations = useSelector(state => state.vaccinationsReducer.vaccinations)
  return (
    <div className={'vaccinations'}>
      <Box
        renderTitle={() => <Text className={'vaccinations__counter'} weight={'regular'} size={'md'}>{`[${vaccinations.length}]`}</Text>}
        classes={{ title: 'vaccinations__title', content: 'vaccinations__box' }} title={'חיסונים'}>
        <DynamicTable
          items={vaccinations.map((v) => ({ ...v, LastDate: formatDate(v.LastDate) }))}
          columns={[{ key: 'VaccinationsAmount', label: 'כמות' }, { key: 'LastDate', label: 'תאריך' }, { key: 'VaccineGroupName', label: 'חיסון' }]}/>
      </Box>
    </div>

  )
}
