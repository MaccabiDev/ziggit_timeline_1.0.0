import React, { useEffect } from 'react';
import './DoctorsPortalApp.scss';
import { PatientDetails } from '../PatientDetails/PatientDetails';
import { useDispatch } from 'react-redux';
import { PortalGrid } from '../../Components/PortalGrid/PortalGrid';
import { appInit } from '../../Actions/AppInit';

export const DoctorsPortalApp = (props) => {
  const dispatch = useDispatch()
  useEffect(() => { // fetch data when app mount
    dispatch(appInit());
  }, [])
  return (
    <div className={'app-container'}>
      <PatientDetails />
      <PortalGrid/>
    </div>
  )
};
