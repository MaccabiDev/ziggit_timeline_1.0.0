import React from 'react';
import { useSelector } from 'react-redux';
import { PersonalDetails } from '../../Components/PersonalDetails/PersonalDetails';
import { Flex } from '../../UI';
import { Remarks } from '../../Components/Remarks/Remarks';
import { Registries } from '../../Components/Registries/Registries';

export const PatientDetails = (props) => {
  const memberInformation = useSelector(state => state.patientDetailsReducer.memberInformation)
  const registries = useSelector(state => state.patientDetailsReducer.registries)

  return (
    <Flex fullWidth justify={'space-between'} row>
      {memberInformation && <PersonalDetails
        memberInformation={memberInformation}/>}
      <Flex align={'flex-end'}>
        {memberInformation && <Remarks remarks={memberInformation.remarks}/>}
        {registries && <Registries registries={registries}/> }
      </Flex>

    </Flex>
  );
}
