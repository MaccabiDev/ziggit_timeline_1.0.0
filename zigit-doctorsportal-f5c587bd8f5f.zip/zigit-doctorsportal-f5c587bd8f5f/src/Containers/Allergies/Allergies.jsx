import React from 'react';
import { Box, Text } from '../../UI';
import './Allergies.scss';
import { DynamicTable } from '../../UI/DynamicTable/DynamicTable';
import { useSelector } from 'react-redux';

export const Allergies = (props) => {
  const allergies = useSelector(state => state.allergiesReducer.allergies)
  return (
    <div className={'allergies'}>
      <Box
        renderTitle={() => <Text className={'allergies__counter'} weight={'regular'} size={'md'}>{`[${allergies.length}]`}</Text>}
        classes={{ title: 'allergies__title', content: 'allergies__box' }} title={'רגישויות'}>
        <DynamicTable
          items={allergies}
          columns={[{ key: 'drug_weakness', label: 'תגובה' }, { key: 'drug_additional', label: 'קבוצה' }, { key: 'drug_name', label: 'תרופה' }]}/>
      </Box>
    </div>

  )
}
