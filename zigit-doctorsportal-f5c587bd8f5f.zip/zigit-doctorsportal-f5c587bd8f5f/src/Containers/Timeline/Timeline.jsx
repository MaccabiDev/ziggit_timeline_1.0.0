import React from 'react';
import { Box } from '../../UI';
import './Timeline.scss';

export const Timeline = (props) => {
  return (
    <div className={'timeline'}>
      <Box classes={{ box: 'timeline__box' }}>

      </Box>
    </div>

  )
}
