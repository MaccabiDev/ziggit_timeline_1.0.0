export * from './Allergies/Allergies.jsx';
export * from './Diagnoses/Diagnoses.jsx';
export * from './DoctorsPortalApp/DoctorsPortalApp.jsx';
export * from './Medicines/Medicines.jsx';
export * from './PatientDetails/PatientDetails.jsx';
export * from './RisksFactors/RisksFactors.jsx';
export * from './Timeline/Timeline.jsx';
export * from './Vaccinations/Vaccinations.jsx';
