import React from 'react';
import { Box } from '../../UI';
import './Medicines.scss';

export const Medicines = (props) => {
  return (

    <Box classes={{ box: 'medicines' }} title={'תרופות'}>

    </Box>

  )
}
