import { SET_MEMBER_INFORMATION, SET_REGISTRIES, SET_REGISTRIES_STATUS, SET_MEMBER_INFORMATION_STATUS } from '../Actions/PatientDetails';
import { ACTION_STATUS } from '../Consts';

const initialState = {
  memberInformation: null,
  registries: null,
  regestiresStatus: ACTION_STATUS.initial,
  regestiresError: null,
  memberInformationStatus: ACTION_STATUS.initial,
  memberInformationError: null
};

export const patientDetailsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_MEMBER_INFORMATION: {
      const { memberInformation } = action;
      return {
        ...state,
        memberInformation,
        memberInformationStatus: ACTION_STATUS.success
      };
    }
    case SET_REGISTRIES: {
      const { registries } = action;
      return {
        ...state,
        registries,
        regestiresStatus: ACTION_STATUS.success
      };
    }
    case SET_REGISTRIES_STATUS: {
      const { regestiresStatus, regestiresError } = action;
      return {
        ...state,
        regestiresStatus,
        regestiresError
      };
    };
    case SET_MEMBER_INFORMATION_STATUS: {
      const { memberInformationStatus, memberInformationError } = action;
      return {
        ...state,
        memberInformationStatus,
        memberInformationError
      };
    }
    default: {
      return state;
    }
  }
};
