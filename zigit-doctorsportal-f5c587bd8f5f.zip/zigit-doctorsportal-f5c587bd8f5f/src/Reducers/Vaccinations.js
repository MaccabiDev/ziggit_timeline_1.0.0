import { SET_VACCINATIONS, SET_VACCINATIONS_STATUS } from '../Actions/Vaccinations';

const initialState = {
  vaccinations: []
};

export const vaccinationsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_VACCINATIONS: {
      const { vaccinations } = action;
      return {
        ...state,
        vaccinations
      };
    };
    case SET_VACCINATIONS_STATUS: {
      const { status, error } = action;
      return {
        ...state,
        status,
        error
      };
    }

    default: {
      return state;
    }
  }
};
