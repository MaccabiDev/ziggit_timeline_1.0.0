import { SET_ALLERGIES, SET_ALLERGIES_STATUS } from '../Actions/Allergies';
import { ACTION_STATUS } from '../Consts';

const initialState = {
  allergies: [],
  status: ACTION_STATUS.initial,
  error: null
};

export const allergiesReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_ALLERGIES: {
      const { allergies } = action;
      return {
        ...state,
        allergies,
        status: ACTION_STATUS.success
      };
    };
    case SET_ALLERGIES_STATUS: {
      const { status, error } = action;
      return {
        ...state,
        status,
        error
      };
    }

    default: {
      return state;
    }
  }
};
