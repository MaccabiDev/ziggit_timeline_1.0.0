import { combineReducers } from 'redux';
import { patientDetailsReducer } from './PatientDetailes';
import { allergiesReducer } from './Allergies';
import { vaccinationsReducer } from './Vaccinations';

export default combineReducers({ patientDetailsReducer, allergiesReducer, vaccinationsReducer });
