import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Flex } from '../Flex/Flex';
import './DynamicTable.scss';

export const DynamicTable = memo((props) => {
  const { items, columns } = props;
  return (
    <Flex className={'dynamic-table'} row>
      {columns.map((col) => {
        return (
          <Flex key={col.key} style={{ flex: 1 }}>
            <Flex row className={'dynamic-table__header'}>
              <Flex className={'dynamic-table__header-inner'}>
                <p>{col.label}</p>
              </Flex>

            </Flex>
            {items.map((item, i) => <Flex className={'dynamic-table__row'} key={`${col.key}${i}`} row>
              <p>{item[col.key]}</p>
            </Flex>)}
          </Flex>
        )
      })}
    </Flex>
  )
})
DynamicTable.propTypes = {
  columns: PropTypes.arrayOf(PropTypes.object), // array of columns, each column object should have the following fields:
  // label: name of the column, key: the name of the field in 'items' arr objects
  items: PropTypes.array // array of objects, each object will render as a row.
}
