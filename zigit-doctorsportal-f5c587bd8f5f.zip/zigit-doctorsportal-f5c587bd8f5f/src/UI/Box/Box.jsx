import React, { memo } from 'react';
import PropTypes from 'prop-types';
import './Box.scss';
export const Box = memo((props) => {
  const { children, classes, title, renderTitle, ...rest } = props;
  let titleClass = ''; let boxClass = ''; let boxContentClass = '';
  if (classes) {
    titleClass = classes.title;
    boxClass = classes.box;
    boxContentClass = classes.content;
  }
  return (
    <div {...rest} className={`box ${boxClass}`}>
      <div className={`box__title-container ${titleClass}` }>
        { title && <p>{title}</p>}
        {renderTitle && renderTitle()}
      </div>
      <div className={`box__content ${boxContentClass}`}>
        {children}
      </div>
    </div>
  )
})
Box.propTypes = {
  renderTitle: PropTypes.func, // function for rendreing the title (when title is not just a string)
  title: PropTypes.string,
  classes: PropTypes.shape({
    box: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.string
  })
}
