import React, { memo } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import './Text.scss'

export const Text = memo((props) => {
  const { children, size, color, weight, className, ...rest } = props;
  const classes = classNames({
    [`text-${size}`]: size,
    [`text-${color}`]: color,
    [`text-${weight}`]: weight
  }, className)
  return (
    <p className={classes} {...rest}>{children}</p>
  )
})

Text.propTypes = {
  size: PropTypes.oneOf(['small', 'base', 'md', 'lg', 'xl', 'xxl']),
  color: PropTypes.oneOf(['primary', 'danger', 'standard', 'standard-dark', 'standard-light']),
  weight: PropTypes.oneOf(['light', 'regular', 'medium', 'bold'])
}
