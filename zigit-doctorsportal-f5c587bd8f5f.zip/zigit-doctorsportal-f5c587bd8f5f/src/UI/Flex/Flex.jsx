import React, { memo } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import './Flex.scss'

export const Flex = memo((props) => {
  const { children, justify, align, row, wrap, center, fullWidth, className, ...rest } = props;
  const classes = classNames({
    [`justify-${justify}`]: justify,
    [`align-${align}`]: align,
    'flex-row': row,
    wrap: wrap,
    center: center,
    fullWidth: fullWidth
  }, 'flex', className)
  return (
    <div className={classes} {...rest}>{children}</div>
  )
})

Text.propTypes = {
  justify: PropTypes.oneOf(['flex-start', 'flex-end', 'center', 'space-between', 'space-around']),
  align: PropTypes.oneOf(['flex-start', 'flex-end', 'center', 'space-between', 'space-around']),
  row: PropTypes.bool,
  className: PropTypes.object,
  wrap: PropTypes.bool,
  center: PropTypes.bool,
  fullWidth: PropTypes.bool
}
