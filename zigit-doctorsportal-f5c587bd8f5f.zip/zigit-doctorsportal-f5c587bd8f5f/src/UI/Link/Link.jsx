import React, { memo } from 'react';
import './Link.scss';
export const Link = memo((props) => {
  const { children, ...rest } = props;
  return (
    <a className={'link'} {...rest}>{children}</a>
  )
})
