import React, { memo } from 'react';
import { Flex } from '../../Flex/Flex';
import './TagsList.scss';
import PropTypes from 'prop-types';

export const TagsList = memo(({ tags, maxPerRow, classes }) => {
  const groupedTags = [];
  tags.forEach((o, i) => { // create array of rows. each row contain 'maxPerRow' tags
    const rowNumber = maxPerRow ? Math.floor(i / maxPerRow) : 0;
    if (groupedTags[rowNumber]) {
      groupedTags[rowNumber].push(o)
    } else {
      groupedTags[rowNumber] = [o]
    }
  })

  return (
    <Flex >
      {groupedTags.map((group, i) => {
        return (
          <Flex wrap className={'tags-list__row'} key={i} row>
            {group.map((item, j) => <Flex className={classes && classes.item ? classes.item : '' } key={`${i}${j}`}>
              {item}
            </Flex>)}
          </Flex>
        )
      })}
    </Flex>
  )
})
TagsList.propTypes = {
  tags: PropTypes.array,
  maxPerRow: PropTypes.number,
  classes: PropTypes.object
}
