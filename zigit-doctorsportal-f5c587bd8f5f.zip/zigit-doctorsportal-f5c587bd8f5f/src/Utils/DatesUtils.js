/**
* format date from DateTime string to dd/mm/yyyy
* @param dateStr - String to be formatter e.g 2018-07-11T00:00:00'
* @returns {string} - The return formatted string e.g 11/07/2018
*/

export const formatDate = (dateStr) => {
  const date = new Date(dateStr)
  let dd = date.getDate();
  let mm = date.getMonth() + 1; // January is 0!

  const yyyy = date.getFullYear();
  if (dd < 10) {
    dd = '0' + dd;
  }
  if (mm < 10) {
    mm = '0' + mm;
  }
  const ret = dd + '/' + mm + '/' + yyyy;
  return ret;
}
