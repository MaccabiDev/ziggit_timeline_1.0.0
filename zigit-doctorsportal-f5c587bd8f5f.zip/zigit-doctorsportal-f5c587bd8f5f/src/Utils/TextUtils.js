import { GENDER } from '../Consts'

/**
 * create member age text from gender str (as reurn from api)
 * @param {number} age
 * @param {string} gender 'ז' or 'נ'
 * @returns {string}
 */
export const ageByGender = (age, gender) => {
  if (gender === GENDER.male) {
    return `בן ${age}`
  } else {
    return `בת ${age}`
  }
}
