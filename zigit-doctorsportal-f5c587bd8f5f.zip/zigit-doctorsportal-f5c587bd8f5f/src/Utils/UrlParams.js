/** cretae Object that conatin key,value from query params
 * @returns {object}
 */
export const parseQuery = () => {
  const query = window.location.search;
  const vars = query.slice(1).split('&'); // remove ? and split by &
  const queryObj = {};
  for (var i = 0; i < vars.length; i++) {
    const pair = vars[i].split('=');
    const key = decodeURIComponent(pair[0]);
    const value = decodeURIComponent(pair[1]);
    queryObj[key] = decodeURIComponent(value);
  }
  return queryObj;
}

/**
 *
 * @param {string} key // query string params key
 * @returns {string} // value of the key
 */
export const getQueryParam = (key) => {
  const query = parseQuery();
  return query[key];
}
