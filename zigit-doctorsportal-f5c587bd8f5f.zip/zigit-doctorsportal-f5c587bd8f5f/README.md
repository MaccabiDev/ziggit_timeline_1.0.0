This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`
Set Enviorment to development, Config/Devlopment.js  file will be used.</br>
Runs the app in the development mode.</br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.</br>
The page will reload if you make edits.</br>

### `npm start:staging`
Set Enviorment to staging, Config/Staging.js  file will be used.</br>
Runs the app in the development mode.</br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.</br>
The page will reload if you make edits.</br>

### `npm run build`
Set Enviorment to production, Config/Production.js  file will be used.</br>
Builds the app for production to the `build` folder.</br>
The build is minified and the filenames include the hashes.</br>

### `npm run build:staging`
Set Enviorment to staging, Config/Staging.js  file will be used.</br>
Builds the app for staging to the `build` folder.</br>
The build is minified and the filenames include the hashes.</br>

## Project Sturcture
```
├── README.md
├── node_modules
├── package.json
├── .gitignore
├── .eslintrc.json
├── public
│   ├── favicon.ico
│   ├── index.html
│   
└── src
    ├── index.css - general styles,fonts definitions
    ├── index.js  - app entry-point
    ├── Consts.js - constants used globally across the app
    |── Actions   - redux actions
    |── Assets.js - assets files to include in the bundle 
    |   ├── Fonts
    |   ├── Images
    |
    |── Config     - configuration files based on build time 'REACT_APP_ENV' enviorment varible
    |── Containers - containers components connected to redux store
    |── Components - components without redux binding
    |── Reducers   - redux reducers
    |── Sagas      - redux sagas
    |── Services   - application services, e.g. API clients
    |── Store      - redux store initialization
    |── Theme      - base styles for the application
    |── UI         - UI components e.g. button,text inputs, layouts
    |── Utils      - helper functions used globally across the app

```